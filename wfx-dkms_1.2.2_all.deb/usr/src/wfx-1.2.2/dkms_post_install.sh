#!/bin/sh -e

KERNEL_VERSION=$(uname -r)
WFX_VERSION=${1}
WFX_KEYSET=${2}

echo "KERNEL ${KERNEL_VERSION}: installing WFX Driver V${WFX_VERSION}  KEYSET ${WFX_KEYSET}"

if [ ${WFX_KEYSET} ]; then
	WFX_KEYSET=_${WFX_KEYSET}
fi


sudo rm -f /lib/firmware/wfm_wf200.sec
sudo rm -f /lib/firmware/pds_wf200.json

sudo ln -s /home/pi/wfx_firmware/wfx/wfm_wf200${WFX_KEYSET}_FW${WFX_VERSION}.sec /lib/firmware/wfm_wf200.sec
sudo ln -s /home/pi/wfx_firmware/pds/pds_wf200_FW${WFX_VERSION}.json /lib/firmware/pds_wf200.json

sudo ls -al --color=auto /lib/firmware/wfm_wf200.sec
sudo ls -al --color=auto /lib/firmware/pds_wf200.json

depmod -a

modinfo wfx_core | grep -E "^filename|^version"
modinfo wfx_wlan_sdio | grep -E "^filename|^version"
modinfo wfx_wlan_spi | grep -E "^filename|^version"



